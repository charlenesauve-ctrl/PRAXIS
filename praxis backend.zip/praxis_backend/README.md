# PRAXIS Backend — Django REST API

Strategic decision-support backend for the PRAXIS simulator.

## Stack
- **Python 3.11** + **Django 4.2**
- **Django REST Framework** — API endpoints
- **django-cors-headers** — cross-origin requests from the frontend
- **SQLite** (dev) → PostgreSQL (production)
- **Gunicorn** + **Whitenoise** for production deployment

## API Endpoints

| Method | URL | Description |
|--------|-----|-------------|
| `POST` | `/api/access-request/` | Submit a beta access request |
| `POST` | `/api/log-simulation/` | Log an anonymised simulation run |
| `GET`  | `/api/stats/`           | Public aggregated platform stats |
| `GET`  | `/health/`              | Health check |
| `*`    | `/admin/`               | Django admin dashboard |

### POST `/api/access-request/`
```json
{
  "first_name": "John",
  "last_name": "Smith",
  "email": "j.smith@org.com",
  "organisation": "Ministry of Defence",
  "profile": "gov",
  "message": "We need strategic simulation capabilities."
}
```
Profile values: `gov`, `industry`, `supply`, `think`, `other`

### POST `/api/log-simulation/`
```json
{
  "instability": 60, "conflict": 45, "alliances": 70,
  "dependency": 55, "disruption": 35, "budget": 40, "sanctions": 25,
  "global_risk": 48, "supply_score": 46, "eco_score": 33,
  "scenario": "Baseline 2026"
}
```

### GET `/api/stats/`
```json
{
  "access_requests": 12,
  "total_simulations": 87,
  "recent_simulations_7d": 14,
  "avg_global_risk": 52.3,
  "avg_supply_vulnerability": 44.1,
  "avg_economic_impact": 31.8,
  "top_scenario": "Indo-Pacific escalation"
}
```

## Local setup

```bash
# 1. Clone the repo
git clone https://github.com/YOUR_USERNAME/praxis-backend.git
cd praxis-backend

# 2. Create virtual environment
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Apply migrations
python manage.py migrate

# 5. Create admin user
python manage.py createsuperuser

# 6. Run development server
python manage.py runserver
```

Open http://localhost:8000/admin/ with your superuser credentials.

## Deploy to Railway (free)

1. Push this folder to a GitHub repo
2. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub
3. Select the repo — Railway auto-detects Django via `Procfile`
4. Add environment variable: `SECRET_KEY=your-secure-random-key`
5. Done — Railway gives you a public URL

## Deploy to Render (free)

1. Push to GitHub
2. Go to [render.com](https://render.com) → New Web Service
3. Connect repo, set:
   - Build command: `pip install -r requirements.txt && python manage.py migrate`
   - Start command: `gunicorn praxis_backend.wsgi`
4. Done

## Admin credentials (development only)
- URL: `http://localhost:8000/admin/`
- Username: `admin`
- Password: `praxis2026`

> ⚠️ Change these before deploying to production.

## Connect to the PRAXIS frontend

In `praxis.html`, set the API base URL:
```javascript
const API_BASE = 'https://your-railway-url.up.railway.app';
// or for local dev:
// const API_BASE = 'http://localhost:8000';
```

The frontend automatically:
- POSTs contact form submissions to `/api/access-request/`
- POSTs simulation runs to `/api/log-simulation/`
- GETs live stats from `/api/stats/` and displays them in the hero section

## Project structure
```
praxis_backend/
├── api/
│   ├── migrations/
│   ├── admin.py        ← Custom admin with coloured status badges
│   ├── models.py       ← AccessRequest + SimulationLog
│   ├── serializers.py  ← DRF serializers with validation
│   ├── urls.py
│   └── views.py        ← API views
├── praxis_backend/
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
├── Procfile            ← Railway/Render deployment
├── requirements.txt
├── runtime.txt
└── README.md
```
