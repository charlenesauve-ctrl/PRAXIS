from django.urls import path
from .views import AccessRequestView, SimulationLogView, StatsView

urlpatterns = [
    path('access-request/', AccessRequestView.as_view(), name='access-request'),
    path('log-simulation/', SimulationLogView.as_view(), name='log-simulation'),
    path('stats/', StatsView.as_view(), name='stats'),
]
