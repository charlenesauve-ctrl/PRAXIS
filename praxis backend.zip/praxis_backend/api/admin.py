from django.contrib import admin
from django.utils.html import format_html
from .models import AccessRequest, SimulationLog


@admin.register(AccessRequest)
class AccessRequestAdmin(admin.ModelAdmin):
    list_display = ['full_name', 'email', 'organisation', 'profile',
                    'status_badge', 'created_at']
    list_filter  = ['status', 'profile', 'created_at']
    search_fields = ['first_name', 'last_name', 'email', 'organisation']
    readonly_fields = ['created_at', 'updated_at']
    ordering = ['-created_at']
    actions = ['mark_approved', 'mark_reviewed', 'mark_rejected']

    fieldsets = (
        ('Applicant', {
            'fields': ('first_name', 'last_name', 'email', 'organisation', 'profile')
        }),
        ('Request', {
            'fields': ('message', 'status')
        }),
        ('Metadata', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

    def full_name(self, obj):
        return f"{obj.first_name} {obj.last_name}"
    full_name.short_description = 'Name'

    def status_badge(self, obj):
        colours = {
            'pending':  '#ffb830',
            'reviewed': '#00e5ff',
            'approved': '#6dffb3',
            'rejected': '#ff5e1f',
        }
        colour = colours.get(obj.status, '#888')
        return format_html(
            '<span style="background:{};color:#07090f;padding:2px 8px;'
            'border-radius:3px;font-size:11px;font-weight:700">{}</span>',
            colour, obj.status.upper()
        )
    status_badge.short_description = 'Status'

    @admin.action(description='Mark selected as Approved')
    def mark_approved(self, request, queryset):
        queryset.update(status='approved')

    @admin.action(description='Mark selected as Reviewed')
    def mark_reviewed(self, request, queryset):
        queryset.update(status='reviewed')

    @admin.action(description='Mark selected as Rejected')
    def mark_rejected(self, request, queryset):
        queryset.update(status='rejected')


@admin.register(SimulationLog)
class SimulationLogAdmin(admin.ModelAdmin):
    list_display  = ['id', 'scenario', 'global_risk_display',
                     'supply_score', 'eco_score', 'created_at']
    list_filter   = ['scenario', 'created_at']
    readonly_fields = ['created_at']
    ordering      = ['-created_at']

    def global_risk_display(self, obj):
        colour = '#ff5e1f' if obj.global_risk >= 75 else \
                 '#ffb830' if obj.global_risk >= 50 else \
                 '#00e5ff' if obj.global_risk >= 25 else '#6dffb3'
        return format_html(
            '<span style="color:{};font-weight:700">{}/100</span>',
            colour, obj.global_risk
        )
    global_risk_display.short_description = 'Global Risk'


# Customise admin branding
admin.site.site_header  = 'PRAXIS — Admin Dashboard'
admin.site.site_title   = 'PRAXIS Admin'
admin.site.index_title  = 'Mission Control'
