from rest_framework import serializers
from .models import AccessRequest, SimulationLog

class AccessRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = AccessRequest
        fields = ['id', 'first_name', 'last_name', 'email',
                  'organisation', 'profile', 'message', 'created_at']
        read_only_fields = ['id', 'created_at']

    def validate_email(self, value):
        return value.lower().strip()

    def validate_first_name(self, value):
        if len(value.strip()) < 2:
            raise serializers.ValidationError("First name must be at least 2 characters.")
        return value.strip()


class SimulationLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = SimulationLog
        fields = ['instability','conflict','alliances','dependency',
                  'disruption','budget','sanctions','global_risk',
                  'supply_score','eco_score','scenario']
