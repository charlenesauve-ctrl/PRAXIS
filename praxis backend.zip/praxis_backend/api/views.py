from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.db.models import Avg, Count
from django.utils import timezone
from datetime import timedelta
from .models import AccessRequest, SimulationLog
from .serializers import AccessRequestSerializer, SimulationLogSerializer


class AccessRequestView(APIView):
    """POST /api/access-request/ — Submit a beta access request."""

    def post(self, request):
        serializer = AccessRequestSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(
                {'success': True, 'message': 'Request received. We will contact you within 48 hours.'},
                status=status.HTTP_201_CREATED
            )
        return Response(
            {'success': False, 'errors': serializer.errors},
            status=status.HTTP_400_BAD_REQUEST
        )


class SimulationLogView(APIView):
    """POST /api/log-simulation/ — Log an anonymised simulation run."""

    def post(self, request):
        serializer = SimulationLogSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'success': True}, status=status.HTTP_201_CREATED)
        return Response({'success': False, 'errors': serializer.errors},
                        status=status.HTTP_400_BAD_REQUEST)


class StatsView(APIView):
    """GET /api/stats/ — Public aggregated stats for the front-end dashboard."""

    def get(self, request):
        total_requests = AccessRequest.objects.count()
        last_7d = timezone.now() - timedelta(days=7)

        sim_stats = SimulationLog.objects.aggregate(
            avg_risk=Avg('global_risk'),
            avg_supply=Avg('supply_score'),
            avg_eco=Avg('eco_score'),
            total_sims=Count('id'),
        )

        recent_sims = SimulationLog.objects.filter(
            created_at__gte=last_7d
        ).count()

        # Top scenario used
        top_scenario = (
            SimulationLog.objects
            .exclude(scenario='')
            .values('scenario')
            .annotate(count=Count('scenario'))
            .order_by('-count')
            .first()
        )

        return Response({
            'access_requests': total_requests,
            'total_simulations': sim_stats['total_sims'] or 0,
            'recent_simulations_7d': recent_sims,
            'avg_global_risk': round(sim_stats['avg_risk'] or 0, 1),
            'avg_supply_vulnerability': round(sim_stats['avg_supply'] or 0, 1),
            'avg_economic_impact': round(sim_stats['avg_eco'] or 0, 1),
            'top_scenario': top_scenario['scenario'] if top_scenario else 'N/A',
        })
