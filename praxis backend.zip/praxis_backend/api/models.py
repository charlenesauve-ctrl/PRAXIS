from django.db import models

class AccessRequest(models.Model):
    PROFILE_CHOICES = [
        ('gov', 'Government / Public institution'),
        ('industry', 'Defence industry'),
        ('supply', 'Supply chain manager'),
        ('think', 'Think tank / Advisory'),
        ('other', 'Other'),
    ]
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('reviewed', 'Reviewed'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]

    first_name   = models.CharField(max_length=100)
    last_name    = models.CharField(max_length=100, blank=True)
    email        = models.EmailField(unique=True)
    organisation = models.CharField(max_length=200, blank=True)
    profile      = models.CharField(max_length=20, choices=PROFILE_CHOICES, blank=True)
    message      = models.TextField(blank=True)
    status       = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    created_at   = models.DateTimeField(auto_now_add=True)
    updated_at   = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Access Request'
        verbose_name_plural = 'Access Requests'

    def __str__(self):
        return f"{self.first_name} {self.last_name} — {self.email} [{self.status}]"


class SimulationLog(models.Model):
    """Stores anonymised simulation runs for analytics."""
    instability  = models.IntegerField()
    conflict     = models.IntegerField()
    alliances    = models.IntegerField()
    dependency   = models.IntegerField()
    disruption   = models.IntegerField()
    budget       = models.IntegerField()
    sanctions    = models.IntegerField()
    global_risk  = models.IntegerField()
    supply_score = models.IntegerField()
    eco_score    = models.IntegerField()
    scenario     = models.CharField(max_length=100, blank=True)
    created_at   = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Simulation Log'
        verbose_name_plural = 'Simulation Logs'

    def __str__(self):
        return f"Simulation #{self.pk} — Risk {self.global_risk}/100 @ {self.created_at.strftime('%Y-%m-%d %H:%M')}"
